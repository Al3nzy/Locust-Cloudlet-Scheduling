package zahra_stra;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.Calendar;
import java.util.List;
import org.cloudbus.cloudsim.*;
import org.cloudbus.cloudsim.core.CloudSim;

/**
 *
 * @author Paradise
 */
public class Strategy4 {
	/** The broker. */
	protected static DatacenterBroker broker;

	/** The cloudlet list. */
	protected static List<Cloudlet> cloudletList;

	/** The vm list. */
	protected static List<Vm> vmList;

	/** The host list. */
	protected static List<Host> hostList;   
        
        /** The experiment name */
	protected static String experimentName;
        
    	/**
	 * Creates main() to run this test
	 */
	public static void main(String[] args) {
            
                experimentName = "Virtual Machines Sorting Sequence Allocation Strategy";
		Log.printLine("Starting The " + experimentName + "...");

		try {
			
			int num_user = 1;   
			Calendar calendar = Calendar.getInstance();
			boolean trace_flag = false; 
			CloudSim.init(num_user, calendar, trace_flag);
                        
                        broker = Helper.createBroker();
			int brokerId = broker.getId();

			cloudletList = Helper.createCloudletList(brokerId, Constants.NUMBER_OF_CLOUDLETS);
			vmList = Helper.createVmList(brokerId, Constants.NUMBER_OF_VMS);
			hostList = Helper.createHostList(Constants.NUMBER_OF_HOSTS);
                        
			@SuppressWarnings("unused")
			Datacenter datacenter = Helper.createDatacenter("Datacenter",
                                                                        hostList,
                                                                        new VmAllocationPolicySimple(hostList));
                        
                        // sort the virtual machine by execution speed in ascending order
                        Sorter.sortByVmMips(vmList);
                        
			broker.submitVmList(vmList);
			broker.submitCloudletList(cloudletList);                       
                       
                        CloudSim.startSimulation();                                             
                        
                        List<Cloudlet> newList = broker.getCloudletReceivedList();
			Log.printLine("Received " + newList.size() + " cloudlets");

			CloudSim.stopSimulation();
                        
                        Helper.printResults(newList , experimentName);
                     
                        Log.printLine("The " + experimentName + " Finished.");
                }
                catch (Exception e)
		{
			e.printStackTrace();
			Log.printLine("The simulation has been terminated due to an unexpected error");
		}
                
        }    
    
}


