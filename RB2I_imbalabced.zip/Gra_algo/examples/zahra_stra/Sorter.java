package zahra_stra;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.Vm;

/**
 *
 * @author Paradise
 */
public class Sorter {

    
    public static <T extends Cloudlet> void sortByCloudletLength (List<T> cloudletlist){
        
                        Collections.sort(cloudletlist, new Comparator<T>() {
                        
			@Override
			public int compare(T a, T b) throws ClassCastException {
                                
                                Long aLength = a.getCloudletLength();
				Long bLength = b.getCloudletLength();
                                return bLength.compareTo(aLength);
			}
                        
		});
    }   
    
    public static <T extends Vm> void sortByVmMips (List<T> vmlist){
        
                        Collections.sort(vmlist, new Comparator<T>() {
                        
			@Override
			public int compare(T a, T b) throws ClassCastException {
                                
                                Double aMips = a.getMips();
				Double bMips = b.getMips();
                                return -1 * bMips.compareTo(aMips);
			}
                        
		});
    }       
}
