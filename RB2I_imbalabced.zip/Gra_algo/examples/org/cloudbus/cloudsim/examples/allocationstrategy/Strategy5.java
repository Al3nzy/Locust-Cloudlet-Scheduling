/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cloudbus.cloudsim.examples.allocationstrategy;

import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.List;
import org.cloudbus.cloudsim.*;
import org.cloudbus.cloudsim.core.CloudSim;

/**
 *
 * @author Paradise
 */
public class Strategy5 {
	/** The broker. */
	protected static DatacenterBroker broker;

	/** The cloudlet list. */
	protected static List<Cloudlet> cloudletList;

	/** The vm list. */
	protected static List<Vm> vmList;

	/** The host list. */
	protected static List<Host> hostList;   
        
        /** The experiment name */
	protected static String experimentName;
        
        protected static double [][] execTime= null;
        
    	/**
	 * Creates main() to run this test
	 */
	public static void main(String[] args) {
            
                experimentName = "Greedy Allocation Strategy";
		Log.printLine("Starting The " + experimentName + "...");

		try {
			
			int num_user = 1;   
			Calendar calendar = Calendar.getInstance();
			boolean trace_flag = false; 
			CloudSim.init(num_user, calendar, trace_flag);
                        
                        broker = Helper.createBroker();
			int brokerId = broker.getId();

			cloudletList = Helper.createCloudletList(brokerId, Constants.NUMBER_OF_CLOUDLETS);
			vmList = Helper.createVmList(brokerId, Constants.NUMBER_OF_VMS);
			hostList = Helper.createHostList(Constants.NUMBER_OF_HOSTS);
                        
			@SuppressWarnings("unused")
			Datacenter datacenter = Helper.createDatacenter("Datacenter",
                                                                        hostList,
                                                                        new VmAllocationPolicySimple(hostList));
                        
                        // Step 1: sort the cloud task by instruction length in descending order
                        Sorter.sortByCloudletLength(cloudletList);
                        
                        // Step 2: sort the virtual machine by execution speed in ascending order
                        Sorter.sortByVmMips(vmList);
                        
                        broker.submitVmList(vmList);
			broker.submitCloudletList(cloudletList); 
                        
                        //Step 3: define an execution time matrix
                        
//                        DecimalFormat dft = new DecimalFormat("###.##");
//                        String indent = "    ";
                        execTime = new double[cloudletList.size()][vmList.size()];
                        for (int row = 0; row < cloudletList.size(); ++row){
                                for (int col = 0; col < vmList.size(); ++col){
                                    execTime[row][col] = cloudletList.get(row).getCloudletLength() /
                                                            vmList.get(col).getMips();
                                }
                        }
                        printExecTimes();
                        
                        //Step 4: assign cloud tasks to the vms according to minimum response time
                        double [] responseTime = new double[vmList.size()];
                        double [] waitTime = new double[vmList.size()];
                        for (int c = 0; c < waitTime.length; c++){
                                waitTime [c] = 0.0;
                        }
                            
                        for (int m = 0; m < cloudletList.size(); ++m){
                            
                                for (int c = 0; c < responseTime.length; c++){
                                        responseTime [c] = 0.0;
                                }
                            // compute the cloud task's response time on all vms
                                for (int n = 0; n < vmList.size(); ++n){
                                        responseTime [n] = (execTime [m][n] + waitTime[n]) ;
                                        
//                                        Log.print(dft.format(responseTime[n]) + indent);
                                }
                                // find vm with minimum response time
                                double minTime = Double.MAX_VALUE;
                                int idx = -1;
                                for (int c = 0; c < responseTime.length; ++c){
                                    if (responseTime [c] <= minTime){
                                            minTime = responseTime [c];
                                            idx = c;
                                    }
                                }
//                                Log.printLine("minTime: " + minTime);
                                
                                //assign the cloud task to selected vm
                                broker.bindCloudletToVm(cloudletList.get(m).getCloudletId(),
                                                        vmList.get(idx).getId());
                                //increase wait time on the selected vm
                                waitTime [idx] += execTime [m][idx];
//                                Log.printLine("");
                        }                                               			                      
                       
                        CloudSim.startSimulation();                                             
                        
                        List<Cloudlet> newList = broker.getCloudletReceivedList();
			Log.printLine("Received " + newList.size() + " cloudlets");

			CloudSim.stopSimulation();
                        
                        Helper.printResults(newList , experimentName);
                     
                        Log.printLine("The " + experimentName + " Finished.");
                }
                catch (Exception e)
		{
			e.printStackTrace();
			Log.printLine("The simulation has been terminated due to an unexpected error");
		}
                
        } 
        
        public static void printExecTimes(){
                        DecimalFormat dft = new DecimalFormat("###.##");
                        String indent = "    ";
                                    Log.printLine("-------------------------------------------------------------------"); 
                        Log.printLine("                       execution time matrix");
                        Log.printLine("-------------------------------------------------------------------");
                        Log.print(indent + indent + indent );
                        for (Vm vm : vmList){
                                Log.print( "  vm " + vm.getId() + indent);
                        }    
                        Log.printLine("");
                        for (int row = 0; row < cloudletList.size(); ++row){
                                Log.print("cloudlet " + cloudletList.get(row).getCloudletId() + indent);
                                for (int col = 0; col < vmList.size(); ++col){
                                    Log.print(dft.format(execTime[row][col]) + indent);
                                }
                                Log.printLine("");
                        }
                        Log.printLine("-------------------------------------------------------------------");                                           
                        
        }
    
}


