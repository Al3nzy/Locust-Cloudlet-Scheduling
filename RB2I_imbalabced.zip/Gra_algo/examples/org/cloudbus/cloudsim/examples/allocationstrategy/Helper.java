/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cloudbus.cloudsim.examples.allocationstrategy;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import org.cloudbus.cloudsim.*;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;

/**
 *
 * @author Paradise
 */
public class Helper {

	/**
	 * Creates the cloudlet list.
	 * 
	 * @param brokerId the broker id
	 * @param cloudletsNumber the cloudlets number
	 * 
	 * @return the list< cloudlet>
	 */
	public static List<Cloudlet> createCloudletList(int brokerId, int cloudletsNumber) {
		// Creates a container to store Cloudlets
		LinkedList<Cloudlet> list = new LinkedList<Cloudlet>();

		UtilizationModel utilizationModel = new UtilizationModelFull();

		Cloudlet[] cloudlet = new Cloudlet[cloudletsNumber];

		for(int i=0;i<cloudletsNumber;i++){
			cloudlet[i] = new Cloudlet(i,
                                                   Constants.CLOUDLET_LENGTH[i],
                                                   Constants.CLOUDLET_PES, 
                                                   Constants.CLOUDLET_FILESIZE, 
                                                   Constants.CLOUDLET_OUTPUTSIZE, 
                                                   utilizationModel, 
                                                   utilizationModel, 
                                                   utilizationModel);
			// setting the owner of these Cloudlets
			cloudlet[i].setUserId(brokerId);
			list.add(cloudlet[i]);
		}

		return list;
	}       
    
	/**
	 * Creates the vm list.
	 * 
	 * @param brokerId the broker id
	 * @param vmsNumber the vms number
	 * 
	 * @return the list< vm>
	 */
	public static List<Vm> createVmList(int brokerId, int vmsNumber) {
		List<Vm> vms = new ArrayList<Vm>();
		for (int i = 0; i < vmsNumber; i++) {
			
			vms.add(new Vm( i,
					brokerId,
					Constants.VM_MIPS[i],
					Constants.VM_PES,
					Constants.VM_RAM,
					Constants.VM_BW,
					Constants.VM_SIZE,
					"Xen",
					new CloudletSchedulerSpaceShared()));
		}
		return vms;
	}

	/**
	 * Creates the host list.
	 * 
	 * @param hostsNumber the hosts number
	 * 
	 * @return the list< power host>
	 */
	public static List<Host> createHostList(int hostsNumber) {
		List<Host> hostList = new ArrayList<Host>();
                
                List<Pe> peList = new ArrayList<Pe>();
                for (int j = 0; j < Constants.HOST_PES; j++) {
                        peList.add(new Pe(j, new PeProvisionerSimple(Constants.HOST_MIPS)));
                }
		for (int i = 0; i < hostsNumber; i++) {
			
                        hostList.add(new Host(
					i,
					new RamProvisionerSimple(Constants.HOST_RAM),
					new BwProvisionerSimple(Constants.HOST_BW),
					Constants.HOST_STORAGE,
					peList,
					new VmSchedulerSpaceShared(peList)));
		}
		return hostList;
	}

	/**
	 * Creates the broker.
	 * 
	 * @return the datacenter broker
	 */
	public static DatacenterBroker createBroker() {
		DatacenterBroker broker = null;
		try {
			broker = new DatacenterBroker("Broker");
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
		return broker;
	}

	public static Datacenter createDatacenter(String name, 
                                                    List<Host> hostList,
                                                    VmAllocationPolicy vmAllocationPolicy){

		//    Create a DatacenterCharacteristics object that stores the
		//    properties of a data center: architecture, OS, list of
		//    Machines, allocation policy: time- or space-shared, time zone
		//    and its price (G$/Pe time unit).
		String arch = "x86";      // system architecture
		String os = "Linux";          // operating system
		String vmm = "Xen";
		double time_zone = 10.0;         // time zone this resource located
		double cost = 3.0;              // the cost of using processing in this resource
		double costPerMem = 0.05;		// the cost of using memory in this resource
		double costPerStorage = 0.001;	// the cost of using storage in this resource
		double costPerBw = 0.0;			// the cost of using bw in this resource
		LinkedList<Storage> storageList = new LinkedList<Storage>();	//we are not adding SAN devices by now

	       DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
	                arch, os, vmm, hostList, time_zone, cost, costPerMem, costPerStorage, costPerBw);


		//  Finally, we need to create a PowerDatacenter object.
		Datacenter datacenter = null;
		try {
			datacenter = new Datacenter(name, characteristics, vmAllocationPolicy, storageList, 0);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return datacenter;
	}   
        
	/**
	 * Prints the Cloudlet objects
	 * @param list  list of Cloudlets
	 */
	public static void printResults(List<Cloudlet> list, String experimentName) {
		int size = list.size();
		Cloudlet cloudlet;

		String indent = "    ";
		Log.printLine();
                Log.printLine("========================================================================" );
		Log.printLine("Results of " + experimentName );
                Log.printLine("========================================================================" );
		Log.printLine("Cloud Task NO" + indent +
				indent + "VM NO" + indent + indent + "Run Time" + indent + "Start Time" + indent + "Finish Time" );
                Log.printLine("------------------------------------------------------------------------" );

		DecimalFormat dft = new DecimalFormat("###.##");
		for (int i = 0; i < size; i++) {
			cloudlet = list.get(i);
			Log.printLine(  indent + cloudlet.getCloudletId() + indent +
                                                indent + indent + indent + cloudlet.getVmId() + indent +
						indent + indent + dft.format(cloudlet.getActualCPUTime()) +
						indent + indent + dft.format(cloudlet.getExecStartTime())+ indent + indent + indent + dft.format(cloudlet.getFinishTime())
                                              );
			}
                Log.printLine("========================================================================" );
		}

}         
        
