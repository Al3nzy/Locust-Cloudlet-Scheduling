/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cloudbus.cloudsim.examples.allocationstrategy;

/**
 *
 * @author Paradise
 */
public class Constants {
    
        public final static int NUMBER_OF_CLOUDLETS = 10;        

    	public final static int NUMBER_OF_VMS = 5;

	public final static int NUMBER_OF_HOSTS = 5;  
        
        // VMs characteristics
        public final static int[] VM_MIPS = { 278, 289, 132, 209, 286 };
        public final static int VM_PES	= 1;
	public final static int VM_RAM	= 1024;
	public final static long VM_BW	= 100000; // 100 Mbit/s
	public final static long VM_SIZE = 2500; // 2.5 GB
        
        // Cloudlets characteristics
        public final static int[] CLOUDLET_LENGTH = { 19365, 49809, 30218, 44157, 16754,
                                                      18336, 20045, 31493, 30727, 31017 };
        public final static long CLOUDLET_FILESIZE   = 300;
	public final static long CLOUDLET_OUTPUTSIZE = 300;
        public final static int CLOUDLET_PES	= 1;
    
        // Hosts characteristics
        public final static int HOST_MIPS	 = 500;
	public final static int HOST_PES	 = 1;
	public final static int HOST_RAM	 = 1024;
	public final static int HOST_BW		 = 1000000; // 1 Gbit/s
	public final static int HOST_STORAGE = 1000000; // 1 GB
}
